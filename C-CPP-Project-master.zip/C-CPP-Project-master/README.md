# C-CPP-Project
Here You will find some easy C and C++ project.

To Run the code you firstly need to add graphic.h header file in your compiler.
then Run the code. Else you will get compilation Error.

<h2> 1.Digital Clock </h2>
<p><i> when you run the program... your clock will look like this.</i> </p>
  <img src="Picture/Digital Clock.PNG" align="Left" height="400px"> 
  <br><br><br><br><br><br><br><br>  <br><br><br><br><br><br><br><br>
  <h2 style="margin-top:600px" align="left"> 2.Analog Clock </h2>
  <p><i> when you run the program... your clock will look like this.</i> </p>
  
  <br>
  <img src="Picture/analog_clock.png" align="Left" height="400px">
    <br><br><br><br><br><br><br><br>  <br><br><br><br><br><br><br><br>
    <h2> 3.Propose Girls </h2>
    <br>
    <p> Here a man will walk and propose a girl </p>
  <img src="Picture/propose-1.png" align="Left" height="400px">
    <br><br><br><br><br><br><br><br>  <br><br><br><br><br><br><br><br>
  <img src="Picture/propose-2.png" align="Left" height="400px">
    
